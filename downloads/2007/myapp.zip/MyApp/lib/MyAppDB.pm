package MyAppDB;

use base qw/DBIx::Class::Schema/;

__PACKAGE__->load_classes({
    MyAppDB => [qw/ Users /]
});

1;