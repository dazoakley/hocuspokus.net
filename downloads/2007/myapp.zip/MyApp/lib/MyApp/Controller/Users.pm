package MyApp::Controller::Users;

use strict;
use warnings;
use base 'Catalyst::Controller';

=head1 NAME

MyApp::Controller::Users - Catalyst Controller

=head1 DESCRIPTION

Catalyst Controller.

=head1 METHODS

=cut


=head2 index 

=cut

sub index : Private {
    my ( $self, $c ) = @_;
    $c->response->redirect('/users/list');
}

=head2 list

Fetch all user objects and pass to users/list.tt in stash to be displayed

=cut
 
sub list : Local {
    my ($self, $c) = @_;
    $c->stash->{users} = [$c->model('MyAppDB::Users')->all];
    $c->stash->{template} = 'users/list.tt';
    $c->stash->{update_uri} = $c->uri_for('/users/_update_user');
}

=head _update_user

Ajax method to update the users table

=cut

sub _update_user : Local {
    my ($self, $c) = @_;
    
    $c->model('MyAppDB::Users')
      ->find({ id => $c->req->params->{id} })
      ->update({
        $c->req->params->{field} => $c->req->params->{value}
      });
    
    $c->res->body( $c->req->params->{value} );
}


=head1 AUTHOR

Darren Oakley

=head1 LICENSE

This library is free software, you can redistribute it and/or modify
it under the same terms as Perl itself.

=cut

1;
