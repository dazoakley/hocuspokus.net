CREATE TABLE users (
        id          INTEGER PRIMARY KEY,
        firstname    TEXT,
        lastname    TEXT
);

INSERT INTO users VALUES (1, 'Matt', 'Parkman');
INSERT INTO users VALUES (2, 'Claire', 'Bennet');
INSERT INTO users VALUES (3, 'Hiro', 'Nakamura');
INSERT INTO users VALUES (4, 'Jessica', 'Sanders');
INSERT INTO users VALUES (5, 'Niki', 'Sanders');
INSERT INTO users VALUES (6, 'Peter', 'Petrelli');
INSERT INTO users VALUES (7, 'Nathan', 'Petrelli');
INSERT INTO users VALUES (8, 'Mohinder', 'Suresh');
INSERT INTO users VALUES (9, 'Isaac', 'Mendez');
INSERT INTO users VALUES (10, 'Micah', 'Sanders');
